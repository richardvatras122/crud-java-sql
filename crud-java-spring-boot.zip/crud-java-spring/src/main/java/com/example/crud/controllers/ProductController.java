package com.example.crud.controllers;

import com.example.crud.domain.product.ProductRepository;
import com.example.crud.domain.product.RequestProduct;
import com.example.crud.domain.product.product;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/product")
public class ProductController {
    @Autowired
    private ProductRepository repository;
    @GetMapping
    public ResponseEntity getAllProduct(){
        var allproduct = repository.findAll();
        return ResponseEntity .ok(allproduct);


    }

    @PostMapping
    public ResponseEntity registerProduct(@RequestBody @Valid RequestProduct data){
        product newProduct = new product(data);
        repository.save(newProduct);
        return ResponseEntity.ok().build();
    }

    @PutMapping()
    public ResponseEntity updateProduct(@RequestBody @Valid RequestProduct data){
        product product1 = repository.getReferenceById(data.id());
        product1.setName(data.name());
        product1.setPrice_in_cents(data.price_in_cents());
        return ResponseEntity.ok(product1);
    }

}
